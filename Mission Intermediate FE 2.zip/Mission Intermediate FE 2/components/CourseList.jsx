import courseImage1 from '../components/assets/1.png'; 
import courseImage2 from '../components/assets/2.png';
import courseImage3 from '../components/assets/3.png';
import courseImage4 from '../components/assets/4.png';
import courseImage5 from '../components/assets/5.png';
import courseImage6 from '../components/assets/6.png';
const courses = [
    { id: 1, img: courseImage1, alt: "Course 1" },
    { id: 2, img: courseImage2, alt: "Course 2" },
    { id: 3, img: courseImage3, alt: "Course 3" },
    { id: 4, img: courseImage4, alt: "Course 4" },
    { id: 5, img: courseImage5, alt: "Course 5" },
    { id: 6, img: courseImage6, alt: "Course 6" },
];

const CourseList = () => {
    return (
        <>
            <section className="featured-videos">
                <h2>Koleksi Video Pembelajaran Unggulan</h2>
                <p className="subtitle">Jelajahi Dunia Pengetahuan Melalui Pilihan Kami!</p>

                <div className="class-categories">
                    <p className="category-link active">Semua Kelas</p>
                    <p className="category-link">Pemasaran</p>
                    <p className="category-link">Desain</p>
                    <p className="category-link">Pengembangan Diri</p>
                    <p className="category-link">Bisnis</p>
                </div>
            </section>

            <section className="course-grid">
                {courses.map(course => (
                    <div className="course-card" key={course.id}>
                        <img 
                            src={course.img}
                            alt={course.alt} 
                            style={{ height: 'fit-content' }}
                        />
                    </div>
                ))}
            </section>
        </>
    );
}

export default CourseList;