
import './style/StyleNavbar.css'; 
import logoImage from '../components/assets/logo.png'; 
import profileImage from '../components/assets/pp.123.png';
const Navbar = () => {
    return (
        <header className="navbar">
            <img 
                src={logoImage}
                alt="Logo" 
                className="header-logo" 
                width="200px" 
                height="50px"
            />
        </header>
    );
}

export default Navbar;