import React from 'react';
const Newsletter = () => {
    const handleSubmit = (e) => {
        e.preventDefault();
        alert('Form disubmit! (Aksi sesungguhnya perlu diimplementasikan)');
    };

    return (
        <section className="hero-section"> 
            <div className="newsletter-content">
                <div className="newsletter-text">
                    <div className="label">NEWSLETTER</div>
                    <h4>Mau Belajar Lebih Banyak?</h4>
                    <p>Daftarkan dirimu untuk mendapatkan informasi terbaru dan penawaran spesial dari program-program terbaik hariesok.id</p>
                    <form className="subscribe-form" onSubmit={handleSubmit}>
                        <input type="email" placeholder="Masukkan Emailmu" required />
                        <button type="submit">Subscribe</button>
                    </form>
                </div>
            </div>
        </section>
    );
}

export default Newsletter;