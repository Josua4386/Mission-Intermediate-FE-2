import { createBrowserRouter } from "react-router-dom";
import Beranda from "../pages/Beranda";
import Daftar from "../pages/Daftar";
import Masuk from "../pages/Masuk";

export const router = createBrowserRouter([
    {
        path: "daftar/",
        element: <Daftar/>,
    },
    {
        path: "/Beranda",
        element: <Beranda/>,
    },
    {
        path: "/Masuk",
        element: <Masuk/>,
    },
     {
        path: "*",
        element: <h1>404 - Halaman Tidak Ditemukan!</h1>,
    }
]);