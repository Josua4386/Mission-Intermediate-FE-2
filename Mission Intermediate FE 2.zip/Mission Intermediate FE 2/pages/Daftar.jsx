import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../components/style/Regist.css'; 
import Navbar1 from '../components/navbar1';
import toggleIcon from '../components/assets/Logo2.png';

const GOOGLE_LOGO_URL = "https://icon2.cleanpng.com/20240216/yhs/transparent-google-logo-google-logo-with-colorful-letters-on-black-1710875297222.webp";
const Daftar = () => { 
    const [formData, setFormData] = useState({
        fullname: '',
        email: '',
        countryCode: '+62',
        phone: '',
        password: '',
        confirmPassword: ''
    });
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        const key = name === 'confirm-password' ? 'confirmPassword' : name; 
        setFormData(prevData => ({
            ...prevData,
            [key]: value
        }));
    };

    const togglePasswordVisibility = (field) => {
        if (field === 'password') {
            setShowPassword(prev => !prev);
        } else if (field === 'confirmPassword') {
            setShowConfirmPassword(prev => !prev);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (formData.password !== formData.confirmPassword) {
            alert("❌ Konfirmasi Kata Sandi tidak cocok!");
            return;
        }
        const newUserData = {
            fullname: formData.fullname,
            email: formData.email,
            password: formData.password,
            phone: `${formData.countryCode}${formData.phone}`,
        };

        try {
            const existingUsers = JSON.parse(localStorage.getItem('registeredUsers')) || [];   
            const isEmailExist = existingUsers.some(user => user.email === newUserData.email);
            if (isEmailExist) {
                alert("Email ini sudah terdaftar. Silakan gunakan email lain atau Masuk.");
                return;
            }
            existingUsers.push(newUserData);
            localStorage.setItem('registeredUsers', JSON.stringify(existingUsers));
            alert('✅ Pendaftaran Berhasil! Silakan Masuk.');
            navigate('/masuk'); 
        } catch (error) {
            console.error("Gagal menyimpan data:", error);
            alert("Terjadi kesalahan saat menyimpan data.");
        }
    };

    return (
        <>
           <Navbar1 />
             <div className="form-container">  
                <h1>Pendaftaran Akun</h1>
                <p className="subtitle">Yuk, daftarkan akunmu sekarang juga!</p>
                
                <form onSubmit={handleSubmit}> 
                    <div className="form-group">
                        <label htmlFor="fullname">Nama Lengkap</label>
                        <input type="text" id="fullname" name="fullname" value={formData.fullname} onChange={handleChange} required />
                    </div>

                    <div className="form-group">
                        <label htmlFor="email">E-Mail</label>
                        <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} required />
                    </div>

                    <div className="form-group">
                        <label htmlFor="phone">No. Hp</label>
                        <div className="phone-group">
                            <select id="country-code" name="countryCode" value={formData.countryCode} onChange={handleChange}>
                                <option value="+62">🇮🇩 +62</option>
                            </select>
                            <input type="text" id="phone" name="phone" value={formData.phone} onChange={handleChange} required /> 
                        </div>
                    </div>
                    
                    <div className="form-group">
                        <label htmlFor="password">Kata Sandi</label>
                        <div className="password-input-wrapper">
                            <input 
                                type={showPassword ? "text" : "password"} 
                                id="password" 
                                name="password" 
                                value={formData.password}
                                onChange={handleChange}
                                required 
                            />
                            <img 
                                src={toggleIcon} 
                                alt="Toggle Password Visibility" 
                                className="password-toggle"
                                onClick={() => togglePasswordVisibility('password')}
                            />
                        </div>
                    </div>

                    <div className="form-group">
                        <label htmlFor="confirm-password">Konfirmasi Kata Sandi</label>
                        <div className="password-input-wrapper">
                            <input 
                                type={showConfirmPassword ? "text" : "password"} 
                                id="confirm-password" 
                                name="confirm-password"
                                value={formData.confirmPassword}
                                onChange={handleChange}
                                required 
                            />
                            <img 
                                src={toggleIcon} 
                                alt="Toggle Password Visibility" 
                                className="password-toggle"
                                onClick={() => togglePasswordVisibility('confirmPassword')}
                            />
                        </div>
                        <p className="forgot-password-link">
                            <a href="/forgot-password">Lupa Password?</a>
                        </p>
                    </div>

                    <button type="submit" className="btn btn-primary">Daftar</button>
                </form> 
                
                <button type="button" className="btn btn-secondary" onClick={() => navigate('/masuk')}>Masuk</button>
                <p className="separator">atau</p>
                <button type="button" className="btn btn-google">
                    <img src={GOOGLE_LOGO_URL} alt="Google Logo" className="google-logo"/>
                    Daftar dengan Google
                </button>
            </div>
        </> 
    );
}

export default Daftar;