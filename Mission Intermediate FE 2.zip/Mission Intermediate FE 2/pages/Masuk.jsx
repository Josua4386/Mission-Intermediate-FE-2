import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../components/style/Login.css';
import toggleIcon from '../components/assets/Logo2.png';
import Navbar from '../components/navbar1'; 
const GOOGLE_LOGO_URL = "https://icon2.cleanpng.com/20240216/yhs/transparent-google-logo-google-logo-with-colorful-letters-on-black-1710875297222.webp";
const Masuk = () => {
    const [loginData, setLoginData] = useState({
        email: '',
        password: ''
    });
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();
    const handleChange = (e) => {
        const { name, value } = e.target;
        setLoginData(prevData => ({
            ...prevData,
            [name]: value
        }));
    };
    const togglePasswordVisibility = () => {
        setShowPassword(prev => !prev);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        
        try {
            const existingUsers = JSON.parse(localStorage.getItem('registeredUsers')) || [];
            const user = existingUsers.find(
                u => u.email === loginData.email && u.password === loginData.password
            );

            if (user) {
                alert(`✅ Selamat datang kembali, ${user.fullname}! Login berhasil.`);
                localStorage.setItem('currentUser', JSON.stringify(user)); 
                navigate('/beranda');
            } else {
                alert("❌ Login gagal. Email atau Kata Sandi salah.");
            }
        } catch (error) {
            console.error("Error saat mencoba login:", error);
            alert("Terjadi kesalahan sistem saat mencoba login.");
        }
    };

    return (
        <>
        <Navbar/>
        <div className="form-container">
            
            <h1>Masuk Ke Akun</h1>
            <p className="subtitle">Yuk, Lanjutin Belajarmu di videobelajar.</p>
            
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="email">E-Mail</label>
                    <input 
                        type="email" 
                        id="email" 
                        name="email" 
                        value={loginData.email}
                        onChange={handleChange}
                        required 
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="password">Kata Sandi</label>
                    <div className="password-input-wrapper">
                        <input 
                            type={showPassword ? "text" : "password"} 
                            id="password" 
                            name="password" 
                            value={loginData.password}
                            onChange={handleChange}
                            required 
                        />
                        <img 
                            src={toggleIcon} 
                            alt="Toggle Password Visibility" 
                            className="password-toggle"
                            onClick={togglePasswordVisibility}
                        />
                    </div>
                </div>
                
                <p className="forgot-password-link">
                    <a href="/forgot-password">Lupa Password?</a>
                </p>
                
                <button type="submit" className="btn btn-primary">Masuk</button>
            </form>
            <button type="button" className="btn btn-secondary" onClick={() => navigate('/daftar')}>Daftar</button>
            
            <p className="separator">atau</p>
            <button type="button" className="btn btn-google">
                <img 
                    src={GOOGLE_LOGO_URL} 
                    alt="Google Logo" 
                    className="google-logo"
                />
                Masuk dengan Google
            </button>
        </div>
        </>
    );
}

export default Masuk;