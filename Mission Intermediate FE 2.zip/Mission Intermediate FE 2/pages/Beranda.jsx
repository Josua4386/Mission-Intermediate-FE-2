import Footer from "../components/footer";
import Navbar from "../components/navbar2";
import CourseList from "../components/CourseList";
import HeroSection from "../components/HeroSection";
import Newsletter from "../components/Newsletter";
import '../components/style/StyleHome.css';
const Beranda = () => {

  return (
    <div>
      <Navbar />
      <HeroSection/>
      <CourseList/>
      <Newsletter/>
      <Footer/>
    </div>
  );
};

export default Beranda;